# quickstart-web-js

- Go to https://developer.deepar.ai, sign up, create the project and the Web app, copy the license key and paste it to index.html (instead of your_license_key_goes_here string)
- Download the SDK from https://developer.deepar.ai and copy the deepar.js, deepar.wasm and models-68-extreme.bin to lib folder
- Open terminal and go to example folder
- Run python server.py in terminal
- Open browser and enter "http://localhost:8888" in the address bar
